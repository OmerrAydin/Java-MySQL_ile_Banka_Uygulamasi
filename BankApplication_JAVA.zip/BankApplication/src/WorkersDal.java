
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class WorkersDal {
    public ArrayList<Workers> get_workers(String grade) throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        ArrayList<Workers> workers = null;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,TC,NAME,SURNAME,PASSWORD,TEL,MAIL,GRADE,TIER,SALARY FROM tbl_workers WHERE GRADE = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, grade);
            resultSet = statement.executeQuery();
            workers = new ArrayList<>();
            while(resultSet.next()){
                workers.add(new Workers(
                        resultSet.getInt("ID"),
                        resultSet.getString("TC"),
                        resultSet.getString("NAME"),
                        resultSet.getString("SURNAME"),
                        resultSet.getString("PASSWORD"), 
                        resultSet.getString("TEL"),
                        resultSet.getString("MAIL"),
                        resultSet.getString("GRADE"),
                        resultSet.getString("TIER"),
                        resultSet.getInt("SALARY")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası yazılımcı: "+e);
        }
        return workers;
    }
    
    public Workers get_workers_with_tc_and_grade(String tc, String grade) throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        Workers worker = null;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,TC,NAME,SURNAME,PASSWORD,TEL,MAIL,GRADE,TIER,SALARY FROM tbl_workers WHERE GRADE = ? and tc = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, grade);
            statement.setString(2, tc);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                worker = new Workers(
                    resultSet.getInt("ID"),
                    resultSet.getString("TC"),
                    resultSet.getString("NAME"),
                    resultSet.getString("SURNAME"),
                    resultSet.getString("PASSWORD"), 
                    resultSet.getString("TEL"),
                    resultSet.getString("MAIL"),
                    resultSet.getString("GRADE"),
                    resultSet.getString("TIER"),
                    resultSet.getInt("SALARY")
                );
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
            return worker;
        }
        return worker;
    }
    
    public Boolean add_worker(String tc, String name, String surname, String password, String tel, String mail, String grade, String tier, int salary){
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_insert = "insert into tbl_workers(tc,name,surname,password,tel,mail,grade,tier,salary) values(?,?,?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(sql_insert);
            statement.setString(1,tc);
            statement.setString(2,name);
            statement.setString(3,surname);
            statement.setString(4,password);
            statement.setString(5,tel);
            statement.setString(6,mail);
            statement.setString(7,grade);
            statement.setString(8,tier);
            statement.setInt(9,salary);
            
            statement.executeUpdate();
            System.out.println("Kayıt eklendi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean update_worker(String tc, String name, String surname, String password, String tel, String mail, String grade, String tier, int salary){
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            if(password.equals("")){ // Adminin yönettiği sayfalardan biriyse
                String sql_update = "update tbl_workers set name=?, surname=?, tel=? ,mail=?, tier=?, salary=? where tc=? and grade=?";
                statement = connection.prepareStatement(sql_update);
                statement.setString(1,name);
                statement.setString(2,surname);
                statement.setString(3,tel);
                statement.setString(4,mail);
                statement.setString(5,tier);
                statement.setInt(6,salary);
                statement.setString(7,tc);
                statement.setString(8,grade);
            }
            else{ //Kişi kendi bilgilerini değişiyorsa
                String sql_update = "update tbl_workers set name=?, surname=?, password=?, tel=? ,mail=?, tier=?, salary=? where tc=? and grade=?";
                statement = connection.prepareStatement(sql_update);
                statement.setString(1,name);
                statement.setString(2,surname);
                statement.setString(3,password);
                statement.setString(4,tel);
                statement.setString(5,mail);
                statement.setString(6,tier);
                statement.setInt(7,salary);
                statement.setString(8,tc);
                statement.setString(9,grade);
            }
            statement.executeUpdate();
            System.out.println("Kayıt güncellendi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean delete_worker(String tc,  String grade){
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_delete = "delete from tbl_workers where tc=? and grade=?";
            statement = connection.prepareStatement(sql_delete);
            statement.setString(1,tc);
            statement.setString(2,grade);
            
            statement.executeUpdate();
            System.out.println("Kayıt silindi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean update_admin(String tc, String name, String surname, String password, String tel, String mail){
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "update tbl_workers set name=?, surname=?, password=?, tel=? ,mail=? where tc=?";
            statement = connection.prepareStatement(sql_update);
            statement.setString(1,name);
            statement.setString(2,surname);
            statement.setString(3,password);
            statement.setString(4,tel);
            statement.setString(5,mail);
            statement.setString(6,tc);
            
            statement.executeUpdate();
            System.out.println("Kayıt güncellendi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
}

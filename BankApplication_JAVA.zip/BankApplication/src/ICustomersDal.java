
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class ICustomersDal {
    public static String registeredTc = "";
    
    public Boolean customers_login_check(String tc, String password)
    {
        Boolean kontrol = false;
        try {
                CustomerDAL customerDal = new CustomerDAL();
                ArrayList<Customers> customers = customerDal.get_customers();
                
                for(Customers customer:customers){

                    if (tc.equals(customer.getTc()) && password.equals(customer.getPassword()))
                    {
                        registeredTc = customer.getTc();
                        kontrol = true;
                        break;
                    }
                }
            
            } catch (SQLException e) {
                System.out.println("Array Error: " + e);
            }
        return kontrol;
    }
    
    public Boolean customers_information_check(String tc, String name, String surname, String password, String tel, String mail, String job){
        Boolean kontrol = true;
        GlobalFunctions globalFunctions = new GlobalFunctions();
        if(tc.equals("") || !globalFunctions.isNumeric(tc) || name.equals("") || globalFunctions.isNumeric(name) || surname.equals("") || globalFunctions.isNumeric(surname) || password.equals("") || tel.equals("") || !globalFunctions.isNumeric(tel) || mail.equals("") || globalFunctions.isNumeric(mail) || job.equals("") || globalFunctions.isNumeric(job)){
            kontrol = false;
        }
        
        return kontrol;
    }
    
    public void populate_table_customers(DefaultTableModel model){
        model.setRowCount(0);
        try {
            CustomerDAL customerDAL = new CustomerDAL();
            ArrayList<Customers> customers = customerDAL.get_customers();
            for(Customers customer:customers){
                Object[] row = {customer.getTc(),customer.getName(),customer.getSurname()};
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
}

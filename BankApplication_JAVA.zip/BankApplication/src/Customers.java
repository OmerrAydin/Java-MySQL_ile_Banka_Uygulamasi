public class Customers {
    private int id;
    private String tc;
    private String name;
    private String surname;
    private String password;
    private String tel;
    private String mail;
    private String job;
    private Double remainingBalance;
    private int bankSatisfaction;
    private int remainingDebt;
    
    public Customers(int id,String tc, String name, String surname, String password, String tel, String mail, String job, Double remainingBalance, int bankSatisfaction, int remainingDebt){
        this.tc = tc;
        this.name = name;
        this.surname = surname;
        this.password = password;
        this.tel = tel;
        this.mail = mail;
        this.job = job;
        this.remainingBalance = remainingBalance;
        this.bankSatisfaction = bankSatisfaction;
        this.remainingDebt = remainingDebt;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the tc
     */
    public String getTc() {
        return tc;
    }

    /**
     * @param tc the tc to set
     */
    public void setTc(String tc) {
        this.tc = tc;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the tel
     */
    public String getTel() {
        return tel;
    }

    /**
     * @param tel the tel to set
     */
    public void setTel(String tel) {
        this.tel = tel;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the job
     */
    public String getJob() {
        return job;
    }

    /**
     * @param job the job to set
     */
    public void setJob(String job) {
        this.job = job;
    }

    /**
     * @return the remaining_balance
     */
    public Double getRemainingBalance() {
        return remainingBalance;
    }

    /**
     * @param remainingBalance the remaining_balance to set
     */
    public void setRemainingBalance(Double remainingBalance) {
        this.remainingBalance = remainingBalance;
    }

    /**
     * @return the bankSatisfaction
     */
    public int getBankSatisfaction() {
        return bankSatisfaction;
    }

    /**
     * @param bankSatisfaction the bankSatisfaction to set
     */
    public void setBankSatisfaction(int bankSatisfaction) {
        this.bankSatisfaction = bankSatisfaction;
    }

    /**
     * @return the remainingDebt
     */
    public int getRemainingDebt() {
        return remainingDebt;
    }

    /**
     * @param remainingDebt the remainingDebt to set
     */
    public void setRemainingDebt(int remainingDebt) {
        this.remainingDebt = remainingDebt;
    }
    
}

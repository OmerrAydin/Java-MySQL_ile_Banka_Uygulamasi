/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class GlobalFunctions {
    public boolean isNumeric(String str) { 
        try {  
            Double.valueOf(str);  
            return true;
        } catch(NumberFormatException e){  
            return false;
        }  
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class EftOperations {
    private int id;
    private String senderTc;
    private String senderName;
    private String senderSurname;
    private Double senderRemainingBalance;
    private String receiverTc;
    private String receiverName;
    private String receiverSurname;
    private Double receiverRemainingBalance;
    private Double amount;
    private String comment;
    private String time;
    
    public EftOperations(int id, String senderTc, String senderName, String senderSurname, Double senderRemainingBalance, String receiverTc, String receiverName, String receiverSurname, Double receiverRemainingBalance, Double amount, String comment, String time) {
        this.id = id;
        this.senderTc = senderTc;
        this.senderName = senderName;
        this.senderSurname = senderSurname;
        this.senderRemainingBalance = senderRemainingBalance;
        this.receiverTc = receiverTc;
        this.receiverName = receiverName;
        this.receiverSurname = receiverSurname;
        this.receiverRemainingBalance = receiverRemainingBalance;
        this.amount = amount;
        this.comment = comment;
        this.time = time;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the senderTc
     */
    public String getSenderTc() {
        return senderTc;
    }

    /**
     * @return the senderName
     */
    public String getSenderName() {
        return senderName;
    }

    /**
     * @param senderName the senderName to set
     */
    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    /**
     * @return the senderSurname
     */
    public String getSenderSurname() {
        return senderSurname;
    }

    /**
     * @param senderSurname the senderSurname to set
     */
    public void setSenderSurname(String senderSurname) {
        this.senderSurname = senderSurname;
    }

    /**
     * @return the senderRemainingBalance
     */
    public Double getSenderRemainingBalance() {
        return senderRemainingBalance;
    }

    /**
     * @param senderRemainingBalance the senderRemainingBalance to set
     */
    public void setSenderRemainingBalance(Double senderRemainingBalance) {
        this.senderRemainingBalance = senderRemainingBalance;
    }

    /**
     * @return the receiverTc
     */
    public String getReceiverTc() {
        return receiverTc;
    }

    /**
     * @return the receiverName
     */
    public String getReceiverName() {
        return receiverName;
    }

    /**
     * @param receiverName the receiverName to set
     */
    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    /**
     * @return the receiverSurname
     */
    public String getReceiverSurname() {
        return receiverSurname;
    }

    /**
     * @param receiverSurname the receiverSurname to set
     */
    public void setReceiverSurname(String receiverSurname) {
        this.receiverSurname = receiverSurname;
    }

    /**
     * @return the receiverRemainingBalance
     */
    public Double getReceiverRemainingBalance() {
        return receiverRemainingBalance;
    }

    /**
     * @param receiverRemainingBalance the receiverRemainingBalance to set
     */
    public void setReceiverRemainingBalance(Double receiverRemainingBalance) {
        this.receiverRemainingBalance = receiverRemainingBalance;
    }

    /**
     * @return the amount
     */
    public Double getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }
    
}

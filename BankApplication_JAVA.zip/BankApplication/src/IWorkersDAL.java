
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class IWorkersDAL {
    public static String registeredTc = "";
    
    public Boolean officers_login_check(String tc, String password)
    {
        Boolean kontrol = false;
        String grade = "Officer";
        try {
                WorkersDal workersDal = new WorkersDal();
                ArrayList<Workers> officers = workersDal.get_workers(grade);
                
                for(Workers officer:officers){

                    if (tc.equals(officer.getTc()) && password.equals(officer.getPassword()))
                    {
                        registeredTc = officer.getTc();
                        kontrol = true;
                        break;
                    }
                }
            
            } catch (SQLException e) {
                System.out.println("Array Error: " + e);
            }
        return kontrol;
    }
    public Boolean developers_login_check(String tc, String password)
    {
        Boolean kontrol = false;
        String grade = "Developer";
        try {
                WorkersDal workersDal = new WorkersDal();
                ArrayList<Workers> developers = workersDal.get_workers(grade);
                
                for(Workers developer:developers){

                    if (tc.equals(developer.getTc()) && password.equals(developer.getPassword()))
                    {
                        registeredTc=developer.getTc();
                        kontrol = true;
                        break;
                    }
                }
            
            } catch (SQLException e) {
                System.out.println("Array Error: " + e);
            }
        return kontrol;
    }
    
    public Boolean admins_login_check(String tc, String password)
    {
        Boolean kontrol = false;
        String grade = "Admin";
        try {
                WorkersDal workersDal = new WorkersDal();
                ArrayList<Workers> admins = workersDal.get_workers(grade);
                
                for(Workers admin:admins){

                    if (tc.equals(admin.getTc()) && password.equals(admin.getPassword()))
                    {
                        registeredTc = admin.getTc();
                        kontrol = true;
                        break;
                    }
                }
            
            } catch (SQLException e) {
                System.out.println("Array Error: " + e);
            }
        return kontrol;
    }
    
    public Boolean worker_information_check(String tc, String name, String surname, String password, String tel, String mail, String salary){
        Boolean kontrol = true;
        GlobalFunctions globalFunctions = new GlobalFunctions();
        if(tc.equals("") || !globalFunctions.isNumeric(tc) || name.equals("") || globalFunctions.isNumeric(name) || surname.equals("") || globalFunctions.isNumeric(surname) || password.equals("") || tel.equals("") || !globalFunctions.isNumeric(tel) || mail.equals("") || globalFunctions.isNumeric(mail) || salary.equals("") || !globalFunctions.isNumeric(salary)){
            kontrol = false;
        }
        return kontrol;
    }
    
    public void populate_table_workers(DefaultTableModel model, String grade){
        model.setRowCount(0);
        try {
            WorkersDal workersDal = new WorkersDal();
            ArrayList<Workers> workers = workersDal.get_workers(grade);
            for(Workers worker:workers){
                if(worker.getGrade().equals(grade)){
                    Object[] row = {worker.getTc(),worker.getName() + " " + worker.getSurname(),worker.getTier(),worker.getSalary()};
                    model.addRow(row);
                }
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
}

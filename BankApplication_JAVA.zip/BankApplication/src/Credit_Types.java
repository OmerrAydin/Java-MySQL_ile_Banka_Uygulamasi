/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class Credit_Types {
    private int id;
    private String creditName;
    private int period;
    private Double bankRate;
    
    public Credit_Types(int id, String creditName, int period, Double bankRate){
        this.id = id;
        this.creditName = creditName;
        this.period = period;
        this.bankRate = bankRate;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @return the creditName
     */
    public String getCreditName() {
        return creditName;
    }

    /**
     * @param creditName the creditName to set
     */
    public void setCreditName(String creditName) {
        this.creditName = creditName;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @param period the period to set
     */
    public void setPeriod(int period) {
        this.period = period;
    }

    /**
     * @return the bankRate
     */
    public Double getBankRate() {
        return bankRate;
    }

    /**
     * @param bankRate the bankRate to set
     */
    public void setBankRate(Double bankRate) {
        this.bankRate = bankRate;
    }

    
}

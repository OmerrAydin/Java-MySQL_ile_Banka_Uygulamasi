import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CustomerDAL {
    public ArrayList<Customers> get_customers() throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        ArrayList<Customers> customers = null;
        try{
            connection = dbHelper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select ID,TC,NAME,SURNAME,PASSWORD,TEL,MAIL,JOB,REMAINING_BALANCE,BANK_SATISFACTİON,REMAINING_DEBT from tbl_customers");
            customers = new ArrayList<>();
            while(resultSet.next()){
                customers.add(new Customers(
                        resultSet.getInt("ID"),
                        resultSet.getString("TC"),
                        resultSet.getString("NAME"),
                        resultSet.getString("SURNAME"),
                        resultSet.getString("PASSWORD"), 
                        resultSet.getString("TEL"),
                        resultSet.getString("MAIL"),
                        resultSet.getString("JOB"),
                        resultSet.getDouble("REMAINING_BALANCE"),
                        resultSet.getInt("BANK_SATISFACTİON"),
                        resultSet.getInt("REMAINING_DEBT")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return customers;
    }
    public Boolean add_customer(String tc, String name, String surname, String password, String tel, String mail, String job) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_insert = "insert into tbl_customers(tc,name,surname,password,tel,mail,job,BANK_SATISFACTİON) values(?,?,?,?,?,?,?,5)";
            statement = connection.prepareStatement(sql_insert);
            statement.setString(1,tc);
            statement.setString(2,name);
            statement.setString(3,surname);
            statement.setString(4,password);
            statement.setString(5,tel);
            statement.setString(6,mail);
            statement.setString(7,job);
            
            statement.executeUpdate();
            System.out.println("Kayıt eklendi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Customers get_customers_with_tc(String tc) throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        Customers customer = null;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,TC,NAME,SURNAME,PASSWORD,TEL,MAIL,JOB,REMAINING_BALANCE,BANK_SATISFACTİON,REMAINING_DEBT from tbl_customers where tc=?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, tc);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                customer = new Customers(
                    resultSet.getInt("ID"),
                    resultSet.getString("TC"),
                    resultSet.getString("NAME"),
                    resultSet.getString("SURNAME"),
                    resultSet.getString("PASSWORD"), 
                    resultSet.getString("TEL"),
                    resultSet.getString("MAIL"),
                    resultSet.getString("JOB"),
                    resultSet.getDouble("REMAINING_BALANCE"),
                    resultSet.getInt("BANK_SATISFACTİON"),
                    resultSet.getInt("REMAINING_DEBT")
                );
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
            return customer;
        }
        return customer;
    }
    
    public Boolean update_customer(String tc, String name, String surname, String password, String tel, String mail, String job, Double remaining_balance, int bank_satisfaction, int remaining_debt){
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            if(password.equals("")){ // Memurun yönettiği sayfalardan biriyse
                String sql_update = "update tbl_customers set name=?, surname=?, tel=? ,mail=?, job=?, remaining_balance=?, bank_satisfaction=?, remaining_debt=? where tc=?";
                statement = connection.prepareStatement(sql_update);
                statement.setString(1,name);
                statement.setString(2,surname);
                statement.setString(3,tel);
                statement.setString(4,mail);
                statement.setString(5,job);
                statement.setDouble(6,remaining_balance);
                statement.setInt(7,bank_satisfaction);
                statement.setInt(8,remaining_debt);
                statement.setString(9,tc);
            }
            else{ //Kişi kendi bilgilerini değişiyorsa
                String sql_update = "update tbl_customers set name=?, surname=?, password=?, tel=? ,mail=?, job=?, remaining_balance=?, bank_satisfaction=?, remaining_debt=? where tc=?";
                statement = connection.prepareStatement(sql_update);
                statement.setString(1,name);
                statement.setString(2,surname);
                statement.setString(3,password);
                statement.setString(4,tel);
                statement.setString(5,mail);
                statement.setString(6,job);
                statement.setDouble(7,remaining_balance);
                statement.setInt(8,bank_satisfaction);
                statement.setInt(9,remaining_debt);
                statement.setString(10,tc);
            }
            statement.executeUpdate();
            System.out.println("Kayıt güncellendi");
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
       
    public Boolean delete_customer(String tc) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_delete = "delete from tbl_customers where TC = ?";
            statement = connection.prepareStatement(sql_delete);
            statement.setString(1,tc);
                        
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
}


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Statement;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class CreditDAL {
    public Credit_Types get_credit_type(String creditName, int period) throws SQLException{
        int id = 0;
        Double bank_rate = 0.0;
        Credit_Types credit = null;
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,CREDIT_NAME,PERIOD,BANK_RATE from tbl_credit_types where CREDIT_NAME = ? and PERIOD = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, creditName);
            statement.setInt(2, period);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                credit = new Credit_Types(
                    resultSet.getInt("ID"),
                    resultSet.getString("CREDIT_NAME"),
                    resultSet.getInt("PERIOD"),
                    resultSet.getDouble("BANK_RATE")
                );                
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return credit;
    }
    
    public Credit_Types get_credit_type(int id) throws SQLException{
        Credit_Types credit = null;
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,CREDIT_NAME,PERIOD,BANK_RATE from tbl_credit_types where ID = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                credit = new Credit_Types(
                    resultSet.getInt("ID"),
                    resultSet.getString("CREDIT_NAME"),
                    resultSet.getInt("PERIOD"),
                    resultSet.getDouble("BANK_RATE")
                );                
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return credit;
    }
    
    public Credits get_credit_with_id(int id) throws SQLException{
        Credits credit = null;
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "SELECT ID,CUSTOMER_TC,CREDIT_AMOUNT,MONTHLY_PAYMENT,REMAINING_DEBT,REMAINING_PERIOD,CREDIT_TYPE_ID,TIME,CONFIRMATION FROM tbl_credits WHERE ID = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                credit = (new Credits(
                        resultSet.getInt("ID"),
                        resultSet.getString("CUSTOMER_TC"),
                        resultSet.getDouble("CREDIT_AMOUNT"),
                        resultSet.getDouble("MONTHLY_PAYMENT"),
                        resultSet.getDouble("REMAINING_DEBT"),
                        resultSet.getInt("REMAINING_PERIOD"),
                        resultSet.getInt("CREDIT_TYPE_ID"),
                        resultSet.getString("TIME"),
                        resultSet.getInt("CONFIRMATION")
                ));             
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return credit;
    }
    
    
    
    public Boolean database_add_credit(Credit_Types credit, Customers customer, Double amount, Double monthlyPayment, Double totalPayment) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        
        try {
            connection = dbHelper.getConnection();
            String sql_insert = "insert into tbl_credits(CUSTOMER_TC,CREDIT_AMOUNT,MONTHLY_PAYMENT,REMAINING_DEBT,REMAINING_PERIOD,CREDIT_TYPE_ID,CONFIRMATION) values(?,?,?,?,?,?,0)";
            statement = connection.prepareStatement(sql_insert);
            statement.setString(1,customer.getTc());
            statement.setDouble(2,amount);
            statement.setDouble(3,monthlyPayment);
            statement.setDouble(4,totalPayment);
            statement.setInt(5,credit.getPeriod());
            statement.setInt(6,credit.getId());
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public ArrayList<Credits> get_credits() throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        ArrayList<Credits> credits = null;
        try{
            connection = dbHelper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("SELECT ID,CUSTOMER_TC,CREDIT_AMOUNT,MONTHLY_PAYMENT,REMAINING_DEBT,REMAINING_PERIOD,CREDIT_TYPE_ID,TIME,CONFIRMATION FROM tbl_credits");
            credits = new ArrayList<>();
            while(resultSet.next()){
                credits.add(new Credits(
                        resultSet.getInt("ID"),
                        resultSet.getString("CUSTOMER_TC"),
                        resultSet.getDouble("CREDIT_AMOUNT"),
                        resultSet.getDouble("MONTHLY_PAYMENT"),
                        resultSet.getDouble("REMAINING_DEBT"),
                        resultSet.getInt("REMAINING_PERIOD"),
                        resultSet.getInt("CREDIT_TYPE_ID"),
                        resultSet.getString("TIME"),
                        resultSet.getInt("CONFIRMATION")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return credits;
    }
    
    public ArrayList<Credit_Types> get_credit_types() throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        ArrayList<Credit_Types> credit_types = null;
        try{
            connection = dbHelper.getConnection();
            statement = connection.createStatement();
            String sql_select = "select ID,CREDIT_NAME,PERIOD,BANK_RATE from tbl_credit_types";
            resultSet = statement.executeQuery(sql_select);
            credit_types = new ArrayList<>();
            while(resultSet.next()){
                credit_types.add(new Credit_Types(
                        resultSet.getInt("ID"),
                        resultSet.getString("CREDIT_NAME"),
                        resultSet.getInt("PERIOD"),
                        resultSet.getDouble("BANK_RATE")
                ));                
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return credit_types;
    }
    
    public Boolean update_credit(Credits credit) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "UPDATE tbl_credits SET CUSTOMER_TC=?, CREDIT_AMOUNT=?, MONTHLY_PAYMENT=?, REMAINING_DEBT=?, REMAINING_PERIOD=?, CREDIT_TYPE_ID=? ,TIME=?, CONFIRMATION=? WHERE ID=?";
            statement = connection.prepareStatement(sql_update);
            statement.setString(1,credit.getCustomerTc());
            statement.setDouble(2,credit.getCreditAmount());
            statement.setDouble(3,credit.getMonthlyPayment());
            statement.setDouble(4,credit.getRemainingDebt());
            statement.setInt(5,credit.getRemainingPeriod());
            statement.setInt(6,credit.getCreditTypeId());
            statement.setString(7,credit.getTime());
            statement.setInt(8,credit.getConfirmation());
            statement.setInt(9,credit.getId());
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean delete_credit(Credits credit) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        
        try {
            connection = dbHelper.getConnection();
            String sql_delete = "DELETE FROM tbl_credits WHERE ID=?";
            statement = connection.prepareStatement(sql_delete);
            statement.setInt(1,credit.getId());
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    public Boolean delete_credit(String tc) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        
        try {
            connection = dbHelper.getConnection();
            String sql_delete = "DELETE FROM tbl_credits WHERE TC=?";
            statement = connection.prepareStatement(sql_delete);
            statement.setString(1,tc);
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean update_credit_types(Credit_Types creditType) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "UPDATE tbl_credit_types SET CREDIT_NAME=?,PERIOD=?,BANK_RATE=? WHERE ID=?";
            statement = connection.prepareStatement(sql_update);
            statement.setString(1,creditType.getCreditName());
            statement.setInt(2,creditType.getPeriod());
            statement.setDouble(3,creditType.getBankRate());
            statement.setInt(4,creditType.getId());
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    public String calculate_day(String nowTime, String pastTime){
        String result = "";
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select DATEDIFF(?,?) as day";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, nowTime);
            statement.setString(2, pastTime);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                result = resultSet.getString("day");
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return result;
    }
    
    public String add_day_for_date(String date, int addingDay){
        String result = "";
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select DATE_ADD(?, INTERVAL ? DAY) as datetime;";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, date);
            statement.setInt(2, addingDay);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                result = resultSet.getString("datetime");
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return result;
    }
    public int get_credit_requests_count(String tc){
        int count = -1;
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select count(*) as count from tbl_credits where CUSTOMER_TC = ?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, tc);
            resultSet = statement.executeQuery();
            while(resultSet.next()){
                count = resultSet.getInt("count");
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
                
        return count;
    }
    
    public String get_current_time() throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        String time = "";
        try{
            connection = dbHelper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select ID,TIME from tbl_time");
            while(resultSet.next()){
                time = resultSet.getString("TIME");
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return time;
    }
    
    public String update_current_time(String time) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        int id = 1;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "update tbl_time set TIME=? where ID=?";
            statement = connection.prepareStatement(sql_update);
            statement.setString(1,time);
            statement.setInt(2,id);
            
            statement.executeUpdate();
            connection.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
        }
        return time;
    }
}

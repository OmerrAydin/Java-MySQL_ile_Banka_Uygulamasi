/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class Credits {
    private int id;
    private String customerTc;
    private Double creditAmount;
    private Double monthlyPayment;
    private Double remainingDebt;
    private int remainingPeriod;
    private int creditTypeId;
    private String time;
    private int confirmation;
    
    public Credits(int id, String customerTc, Double creditAmount, Double monthlyPayment, Double remainingDebt, int remainingPeriod, int creditTypeId, String time, int confirmation){
        this.id = id;
        this.customerTc = customerTc;
        this.creditAmount = creditAmount;
        this.monthlyPayment = monthlyPayment;
        this.remainingDebt = remainingDebt;
        this.remainingPeriod = remainingPeriod;
        this.creditTypeId = creditTypeId;
        this.time = time;
        this.confirmation = confirmation;
    }

    /**
     * @return the customerTc
     */
    public String getCustomerTc() {
        return customerTc;
    }

    /**
     * @return the creditAmount
     */
    public Double getCreditAmount() {
        return creditAmount;
    }

    /**
     * @return the monthlyPayment
     */
    public Double getMonthlyPayment() {
        return monthlyPayment;
    }

    /**
     * @param monthlyPayment the monthlyPayment to set
     */
    public void setMonthlyPayment(Double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

    /**
     * @return the remainingDebt
     */
    public Double getRemainingDebt() {
        return remainingDebt;
    }

    /**
     * @param remainingDebt the remainingDebt to set
     */
    public void setRemainingDebt(Double remainingDebt) {
        this.remainingDebt = remainingDebt;
    }

    /**
     * @return the remainingPeriod
     */
    public int getRemainingPeriod() {
        return remainingPeriod;
    }

    /**
     * @param remainingPeriod the remainingPeriod to set
     */
    public void setRemainingPeriod(int remainingPeriod) {
        this.remainingPeriod = remainingPeriod;
    }

    /**
     * @return the creditTypeId
     */
    public int getCreditTypeId() {
        return creditTypeId;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time the time to set
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * @return the confirmation
     */
    public int getConfirmation() {
        return confirmation;
    }

    /**
     * @param confirmation the confirmation to set
     */
    public void setConfirmation(int confirmation) {
        this.confirmation = confirmation;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

}

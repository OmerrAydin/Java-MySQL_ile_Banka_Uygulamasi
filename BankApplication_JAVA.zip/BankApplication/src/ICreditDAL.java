
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class ICreditDAL {
    public Double get_total_payment(Double amount, Double bank_rate, int period){
        Double totalPayment = (amount*bank_rate*period/100) + amount;
        BigDecimal tp = new BigDecimal(totalPayment).setScale(2, RoundingMode.HALF_UP);
        totalPayment = tp.doubleValue();
        return totalPayment;
    }
    public Double get_monthly_payment(Double totalPayment, int period){
        Double monthlyPayment = totalPayment/period;
        BigDecimal mp = new BigDecimal(monthlyPayment).setScale(2, RoundingMode.HALF_UP);
        monthlyPayment = mp.doubleValue();
        return monthlyPayment;
    }
    public void populate_table_credits(DefaultTableModel model,int confirmation){
        model.setRowCount(0);
        try {
            CreditDAL creditDAL = new CreditDAL();
            ArrayList<Credits> credits = creditDAL.get_credits();
            for(Credits credit:credits){
                if(credit.getConfirmation() == confirmation){
                    Object[] row = {credit.getId(), credit.getCustomerTc(), credit.getCreditAmount(), credit.getMonthlyPayment(), credit.getRemainingDebt(), credit.getRemainingPeriod(), credit.getCreditTypeId(), credit.getTime(), credit.getConfirmation()};
                    model.addRow(row);
                }
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public void populate_table_outdated_credits(DefaultTableModel model){
        model.setRowCount(0);
        try {
            CreditDAL creditDAL = new CreditDAL();
            ICreditDAL icreditDAL = new ICreditDAL();
            Credit_Types credit_type = null;
            String timeNow = creditDAL.get_current_time();
            String paymentTime;
            int dayRange;
            ArrayList<Credits> credits = creditDAL.get_credits();
            for(Credits credit:credits){
                if(credit.getConfirmation() == 1){
                    credit_type = creditDAL.get_credit_type(credit.getCreditTypeId());
                    paymentTime = icreditDAL.get_credit_payment_time(credit, credit_type, 30);
                    dayRange = Integer.parseInt(creditDAL.calculate_day(timeNow, paymentTime));
                    if(dayRange>=10){
                        Object[] row = {credit.getId(), credit.getCustomerTc(), credit.getCreditAmount(), credit.getMonthlyPayment(), credit.getRemainingDebt(), credit.getRemainingPeriod(), credit.getCreditTypeId(), paymentTime, dayRange};
                        model.addRow(row);
                        System.out.println(dayRange);
                    }
                }
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public void populate_table_credits_with_tc(DefaultTableModel model, int confirmation, String tc){
        model.setRowCount(0);
        String confmsg="";
        Credit_Types credit_type = null;
        try {
            CreditDAL creditDAL = new CreditDAL();
            ArrayList<Credits> credits = creditDAL.get_credits();
            for(Credits credit:credits){
                if(credit.getConfirmation() == confirmation && credit.getCustomerTc().equals(tc)){
                    if (credit.getConfirmation() == 0){
                        confmsg = "Onaylanmadı";
                    }
                    else{
                        confmsg = "Onaylandı";
                    }
                    
                    if(credit.getTime() == null){
                        credit.setTime("Onaylanmadı");
                    }
                    
                    credit_type = creditDAL.get_credit_type(credit.getCreditTypeId());
                    Object[] row = {credit.getId(), credit.getCustomerTc(), credit.getCreditAmount(), credit.getMonthlyPayment(), credit.getRemainingDebt(), credit.getRemainingPeriod(), credit_type.getCreditName(), credit.getTime(), confmsg};
                    model.addRow(row);
                }
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public void populate_table_credit_types(DefaultTableModel model){
        model.setRowCount(0);
        try {
            CreditDAL creditDAL = new CreditDAL();
            ArrayList<Credit_Types> creditTypes = creditDAL.get_credit_types();
            for(Credit_Types creditType:creditTypes){
                Object[] row = {creditType.getId(), creditType.getCreditName(), creditType.getPeriod(),creditType.getBankRate()};
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public String get_credit_payment_time(Credits credit, Credit_Types credit_type, int day){
        CreditDAL creditDAL = new CreditDAL();
        String creditTime = "";
        creditTime = credit.getTime();
        for(int x = credit.getRemainingPeriod() ; x <= credit_type.getPeriod() ; x++){
            creditTime = creditDAL.add_day_for_date(creditTime, day);
        }
        return creditTime;
    }
    
    
}

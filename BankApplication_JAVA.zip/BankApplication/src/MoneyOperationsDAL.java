
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class MoneyOperationsDAL {
    public ArrayList<EftOperations> get_efts() throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        Statement statement;
        ResultSet resultSet;
        ArrayList<EftOperations> efts = null;
        try{
            connection = dbHelper.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select ID,SENDER_TC,SENDER_NAME,SENDER_SURNAME,SENDER_REMAINING_BALANCE,RECEIVER_TC,RECEIVER_NAME,RECEIVER_SURNAME,RECEIVER_REMAINING_BALANCE,AMOUNT,COMMENT,TIME from tbl_eft");
            efts = new ArrayList<>();
            while(resultSet.next()){
                efts.add(new EftOperations(
                        resultSet.getInt("ID"),
                        resultSet.getString("SENDER_TC"),
                        resultSet.getString("SENDER_NAME"),
                        resultSet.getString("SENDER_SURNAME"),
                        resultSet.getDouble("SENDER_REMAINING_BALANCE"), 
                        resultSet.getString("RECEIVER_TC"),
                        resultSet.getString("RECEIVER_NAME"),
                        resultSet.getString("RECEIVER_SURNAME"),
                        resultSet.getDouble("RECEIVER_REMAINING_BALANCE"),
                        resultSet.getDouble("AMOUNT"),
                        resultSet.getString("COMMENT"),
                        resultSet.getString("TIME")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return efts;
    }
    
    public ArrayList<EftOperations> get_efts(String tc) throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        ArrayList<EftOperations> efts = null;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,SENDER_TC,SENDER_NAME,SENDER_SURNAME,SENDER_REMAINING_BALANCE,RECEIVER_TC,RECEIVER_NAME,RECEIVER_SURNAME,RECEIVER_REMAINING_BALANCE,AMOUNT,COMMENT,TIME from tbl_eft where SENDER_TC=? or RECEIVER_TC=?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, tc);
            statement.setString(2, tc);
            resultSet = statement.executeQuery();
            efts = new ArrayList<>();
            while(resultSet.next()){
                efts.add(new EftOperations(
                        resultSet.getInt("ID"),
                        resultSet.getString("SENDER_TC"),
                        resultSet.getString("SENDER_NAME"),
                        resultSet.getString("SENDER_SURNAME"),
                        resultSet.getDouble("SENDER_REMAINING_BALANCE"), 
                        resultSet.getString("RECEIVER_TC"),
                        resultSet.getString("RECEIVER_NAME"),
                        resultSet.getString("RECEIVER_SURNAME"),
                        resultSet.getDouble("RECEIVER_REMAINING_BALANCE"),
                        resultSet.getDouble("AMOUNT"),
                        resultSet.getString("COMMENT"),
                        resultSet.getString("TIME")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return efts;
    }
    
    public ArrayList<MoneyOperations> get_money_operations(String tc) throws SQLException{
        Connection connection;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        ResultSet resultSet;
        ArrayList<MoneyOperations> moneyOperations = null;
        try{
            connection = dbHelper.getConnection();
            String sql_select = "select ID,TC,NAME,SURNAME,AMOUNT,OPERATION,REMAINING_BALANCE,TIME from tbl_moneyoperations where TC=?";
            statement = connection.prepareStatement(sql_select);
            statement.setString(1, tc);
            resultSet = statement.executeQuery();
            moneyOperations = new ArrayList<>();
            while(resultSet.next()){
                moneyOperations.add(new MoneyOperations(
                        resultSet.getInt("ID"),
                        resultSet.getString("TC"),
                        resultSet.getString("NAME"),
                        resultSet.getString("SURNAME"),
                        resultSet.getDouble("AMOUNT"),
                        resultSet.getString("OPERATION"),
                        resultSet.getDouble("REMAINING_BALANCE"),
                        resultSet.getString("TIME")
                ));
            }
            statement.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println("Bağlantı Hatası: "+e);
        }
        return moneyOperations;
    }
    
    public void add_money(Customers customer, Double amount){
        Double remaining_balance = customer.getRemainingBalance() + amount;
        String tc  = customer.getTc();
        
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "update tbl_customers set remaining_balance=? where tc=?";
            statement = connection.prepareStatement(sql_update);
            statement.setDouble(1,remaining_balance);
            statement.setString(2,tc);
            statement.executeUpdate();
            System.out.println("Kayıt güncellendi");
            connection.close();
            statement.close();
        } catch (Exception e) {
            System.out.println("Hata: " + e);
        }       
    }
    
    public void take_money(Customers customer, Double amount){
        Double remaining_balance = customer.getRemainingBalance() - amount;
        String tc  = customer.getTc();
        
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        try {
            connection = dbHelper.getConnection();
            String sql_update = "update tbl_customers set remaining_balance=? where tc=?";
            statement = connection.prepareStatement(sql_update);
            statement.setDouble(1,remaining_balance);
            statement.setString(2,tc);
            statement.executeUpdate();
            System.out.println("Kayıt güncellendi");
            connection.close();
            statement.close();
        } catch (Exception e) {
            System.out.println("Hata: " + e);
        }       
    }
    
    public Boolean database_add_eft(Customers sender, Customers receiver, Double amount, String comment) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        PreparedStatement statement = null;
        CreditDAL creditDAL = new CreditDAL();        
        try {
            String time = creditDAL.get_current_time();
            connection = dbHelper.getConnection();
            String sql_insert = "insert into tbl_eft(SENDER_TC,SENDER_NAME,SENDER_SURNAME,SENDER_REMAINING_BALANCE,RECEIVER_TC,RECEIVER_NAME,RECEIVER_SURNAME,RECEIVER_REMAINING_BALANCE,AMOUNT,COMMENT,TIME) values(?,?,?,?,?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(sql_insert);
            statement.setString(1,sender.getTc());
            statement.setString(2,sender.getName());
            statement.setString(3,sender.getSurname());
            statement.setDouble(4,sender.getRemainingBalance());
            statement.setString(5,receiver.getTc());
            statement.setString(6,receiver.getName());
            statement.setString(7,receiver.getSurname());
            statement.setDouble(8,receiver.getRemainingBalance());
            statement.setDouble(9,amount);
            statement.setString(10,comment);
            statement.setString(11,time);
            
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    public Boolean database_add_money_operation(Customers customer, Double amount, String operation) {
        Connection connection = null;
        DbHelper dbHelper = new DbHelper();
        CreditDAL creditDAL = new CreditDAL();
        CustomerDAL customerDAL = new CustomerDAL();
        PreparedStatement statement = null;
        try {
            String time = creditDAL.get_current_time();
            customer = customerDAL.get_customers_with_tc(customer.getTc());
            connection = dbHelper.getConnection();
            String sql_insert = "insert into tbl_moneyoperations(TC,NAME,SURNAME,OPERATION,AMOUNT,REMAINING_BALANCE,TIME) values(?,?,?,?,?,?,?)";
            statement = connection.prepareStatement(sql_insert);
            statement.setString(1,customer.getTc());
            statement.setString(2,customer.getName());
            statement.setString(3,customer.getSurname());
            statement.setString(4,operation);
            statement.setDouble(5,amount);
            statement.setDouble(6,customer.getRemainingBalance());
            statement.setString(7,time);
                        
            statement.executeUpdate();
            connection.close();
            statement.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Hata: " + e);
            return false;
        }
    }
    
    
}


import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author omerf
 */
public class IMoneyOperationsDAL {
    public void populate_table_efts_with_tc(DefaultTableModel model,String tc){
        model.setRowCount(0);
        try {
            MoneyOperationsDAL moneyOperationsDAL = new MoneyOperationsDAL();
            ArrayList<EftOperations> efts = moneyOperationsDAL.get_efts(tc);
            Double remainingBalance;
            for(EftOperations eft:efts){
                if (eft.getSenderTc().equals(ICustomersDal.registeredTc)){
                    remainingBalance = eft.getSenderRemainingBalance();
                }else{
                    remainingBalance = eft.getReceiverRemainingBalance();
                }
                Object[] row = {eft.getId(),eft.getSenderTc(),eft.getSenderName()+" "+eft.getSenderSurname(),remainingBalance,eft.getReceiverTc(),eft.getReceiverName()+" "+eft.getReceiverSurname(),eft.getAmount(),eft.getComment(),eft.getTime()};
                model.addRow(row);
            }            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public void populate_table_money_operations_with_tc(DefaultTableModel model, String tc){
        model.setRowCount(0);
        try {
            MoneyOperationsDAL moneyOperationsDAL = new MoneyOperationsDAL();
            ArrayList<MoneyOperations> moneyOps = moneyOperationsDAL.get_money_operations(tc);
            for(MoneyOperations moneyOp:moneyOps){
                Object[] row = {moneyOp.getId(),moneyOp.getTc(),moneyOp.getName()+" "+moneyOp.getSurname(),moneyOp.getAmount(),moneyOp.getOperation(),moneyOp.getRemainingBalance(),moneyOp.getTime()};
                model.addRow(row);
            }            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public void populate_table_efts(DefaultTableModel model){
        model.setRowCount(0);
        try {
            CustomerDAL customerDAL = new CustomerDAL();
            ArrayList<Customers> efts = customerDAL.get_customers();
            for(Customers eft:efts){
                Object[] row = {eft.getTc(),eft.getName(),eft.getSurname()};
                model.addRow(row);
            }
            
        } catch (SQLException ex) {
            System.out.println("Array Error!");
        }
    }
    
    public Boolean eft(Customers sender, Customers receiver, Double amount, String comment){
        MoneyOperationsDAL moneyOperationsDAL = new MoneyOperationsDAL();
        CustomerDAL customerDAL = new CustomerDAL();
        Double remainingBalanceSender = sender.getRemainingBalance();
        Double remainingBalanceReceiver = receiver.getRemainingBalance();
        if(remainingBalanceSender>=amount){
            try {
                moneyOperationsDAL.take_money(sender, amount); //göndericiden parayı  kes
                moneyOperationsDAL.add_money(receiver, amount); //alıcıya parayı ekle
                sender = customerDAL.get_customers_with_tc(sender.getTc());
                receiver = customerDAL.get_customers_with_tc(receiver.getTc());
                moneyOperationsDAL.database_add_eft(sender, receiver, amount, comment); //eft yi database kaydet
                return true;
            } catch (Exception e) {
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    public Boolean eft_receiver_name_control(String tc, String name, String surname){
        CustomerDAL customerDAL = new CustomerDAL();
        try {
            Customers customer = customerDAL.get_customers_with_tc(tc);
            if(customer.getName().equals(name) && customer.getSurname().equals(surname)){
                return true;
            }
            else{
                return false;
            }
        } catch (Exception e) {
            return false;
        }        
    }
    
    
}

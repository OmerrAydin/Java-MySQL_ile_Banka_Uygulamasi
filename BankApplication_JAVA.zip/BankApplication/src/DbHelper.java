import java.sql.*;
public class DbHelper {
   private String username = "root";
   private String password = "password";
   private String dbUrl = "jdbc:mysql://localhost:3306/banka";
   
    /**
     *
     * @return
     * @throws SQLException
     */
    public Connection getConnection() throws java.sql.SQLException{      
       return DriverManager.getConnection(dbUrl,username,password);
    }
    public void show_error_message(java.sql.SQLException e){
        System.out.println("Hata: "+e);
    }
}
